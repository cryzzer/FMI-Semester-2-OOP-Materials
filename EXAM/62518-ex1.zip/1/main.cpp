#include <iostream>

#include "NamedObject.hpp"
#include "NamedObjectArray.hpp"

int main() {
    double obj = 42;
    NamedObject<double> test(12,"testche",obj);
    std::cout<<test.getName() << "\n";
    std::cout<<test.getId() << "\n";
    std::cout<<test.getObject() << "\n";

    double hah = 5;
    NamedObject<double> test1(10,"opii",hah);

    NamedObjectArray<double> arr;
    arr.addObject(test);
    std::cout << "here\n";
    arr.addObject(test1);

    std::cout << arr[0].getId();

}
